package es.JuegosEnRed.SmashRun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmashRunRedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmashRunRedApplication.class, args);
	}
}
