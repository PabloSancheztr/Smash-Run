// Metodo GET
function getPuntos() {
var puntuaciones;

    $.ajax ({
        method: "GET",
        url: "http://localhost:8080/getPuntuaciones",
        headers: {
            "Content-type": "applicaction/json"
        }
    }).done(function(data) {
        puntuaciones =data
        for(var i = 0; i < 10; i++) {
            if(i == 1) {
                postPuntos("Pablo", 100);
            }
            else {
            $("#puntos" + i).html(puntuaciones[i].nombre + "......" + datos[i].puntuacion);
            }
        }
    })
}

// Metodo POST
function postPuntos(name, puntos) {
    $.ajax({
        method:"POST",
        url: "http://localhost:8080/postPuntuaciones",
        data: JSON.stringify(nombre, puntuacion),
        headers: {"Content-type":"application/json"}
    });
}